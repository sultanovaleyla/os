#!/bin/bash
for A in $*
    do echo $A
done
